CustomProfile 1.0.0
Target: Paper 26.2
Java: 25
Build system: Maven

WHAT THIS BUILD DOES
- /profile opens a 54-slot blue-themed profile GUI.
- Shows the player's head, level, world, armor, kills, deaths, play time and walking distance.
- Armor display is read-only in this first version.
- Refresh and close buttons work.

BUILD
1. Install JDK 25 and Maven.
2. Open a terminal in this folder.
3. Run: mvn clean package
4. The plugin jar will be created at: target/CustomProfile-1.0.0.jar
5. Put that jar in the server's plugins folder and restart Paper.

IMPORTANT
This is the first functional GUI version, not a pixel-perfect copy of the TikTok video.
A true 3D character preview and custom background art need a resource pack and/or a more advanced client-side UI approach.
