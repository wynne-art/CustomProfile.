package id.embut.customprofile;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class CustomProfile extends JavaPlugin implements Listener {
    private static final int SIZE = 54;
    private static final Component TITLE =
            Component.text("PLAYER PROFILE", NamedTextColor.AQUA);

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("CustomProfile enabled. Use /profile");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by a player.");
            return true;
        }
        if (!player.hasPermission("customprofile.use")) {
            player.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }
        openProfile(player);
        return true;
    }

    private void openProfile(Player player) {
        Inventory inv = Bukkit.createInventory(player, SIZE, TITLE);

        ItemStack filler = item(Material.BLUE_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < SIZE; i++) inv.setItem(i, filler);

        // Main profile card
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta skull = (SkullMeta) head.getItemMeta();
        skull.setOwningPlayer(player);
        skull.displayName(Component.text(player.getName(), NamedTextColor.AQUA));
        skull.lore(List.of(
                Component.text("Your player profile", NamedTextColor.GRAY),
                Component.text("Level: " + player.getLevel(), NamedTextColor.WHITE),
                Component.text("World: " + player.getWorld().getName(), NamedTextColor.DARK_GRAY)
        ));
        head.setItemMeta(skull);
        inv.setItem(13, head);

        // Equipment slots: actual equipped items, read-only in this first build
        inv.setItem(20, equipment(player.getInventory().getHelmet(), Material.LEATHER_HELMET, "Helmet"));
        inv.setItem(21, equipment(player.getInventory().getChestplate(), Material.LEATHER_CHESTPLATE, "Chestplate"));
        inv.setItem(22, equipment(player.getInventory().getLeggings(), Material.LEATHER_LEGGINGS, "Leggings"));
        inv.setItem(23, equipment(player.getInventory().getBoots(), Material.LEATHER_BOOTS, "Boots"));

        inv.setItem(29, item(Material.IRON_SWORD, "Combat", List.of(
                "Kills: " + player.getStatistic(Statistic.PLAYER_KILLS),
                "Damage dealt: " + player.getStatistic(Statistic.DAMAGE_DEALT)
        )));
        inv.setItem(31, item(Material.EXPERIENCE_BOTTLE, "Player Stats", List.of(
                "Level: " + player.getLevel(),
                "XP progress: " + Math.round(player.getExp() * 100) + "%",
                "Play time: " + player.getStatistic(Statistic.PLAY_ONE_MINUTE) / 20 / 60 + " minutes"
        )));
        inv.setItem(33, item(Material.SHIELD, "Survival Stats", List.of(
                "Deaths: " + player.getStatistic(Statistic.DEATHS),
                "Mob kills: " + player.getStatistic(Statistic.MOB_KILLS),
                "Distance walked: " + player.getStatistic(Statistic.WALK_ONE_CM) / 100 + " m"
        )));

        inv.setItem(45, item(Material.BOOK, "Profile", List.of("Currently viewing your profile")));
        inv.setItem(49, item(Material.BARRIER, "Close", List.of("Click to close this menu")));
        inv.setItem(53, item(Material.CLOCK, "Refresh", List.of("Close and reopen to refresh")));
        player.openInventory(inv);
    }

    private ItemStack equipment(ItemStack equipped, Material emptyIcon, String slotName) {
        if (equipped == null || equipped.getType().isAir()) {
            return item(emptyIcon, slotName, List.of("Empty slot"));
        }
        ItemStack display = equipped.clone();
        ItemMeta meta = display.getItemMeta();
        meta.lore(List.of(Component.text(slotName, NamedTextColor.GRAY),
                Component.text("Equipped item (view only)", NamedTextColor.DARK_GRAY)));
        display.setItemMeta(meta);
        return display;
    }

    private ItemStack item(Material material, String name, List<String> loreLines) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.AQUA));
        if (!loreLines.isEmpty()) {
            meta.lore(loreLines.stream()
                    .map(line -> Component.text(line, NamedTextColor.GRAY))
                    .toList());
        }
        stack.setItemMeta(meta);
        return stack;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!TITLE.equals(event.getView().title())) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();
        if (slot == 49) {
            player.closeInventory();
        } else if (slot == 53) {
            openProfile(player);
        }
    }
}
